﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace filecontrol
{
    public partial class Form1 : Form
    {
        PropertySettings settings = new PropertySettings();
        public Form1()
        {
            InitializeComponent();
        }
        public struct PropertySettings
        {
            public int mainWndSx;
            public int mainWndSy;
            public int mainWndDx;
            public int mainWndDy;
            public int shortkeyWndSx;
            public int shortkeyWndSy;
            public int options;
            public string prefix;
            public string suffix;
            public string input;
            public string message1;
        }
        public void LoadPropertySettings(string filePath)
        {
            foreach(string line in File.ReadAllLines(filePath))
            {
                if(string.IsNullOrWhiteSpace(line)||line.StartsWith("["))
                {
                    continue;
                }

                var parts = line.Split('=');
                if (parts.Length != 2) continue;

                string key = parts[0].Trim();
                string value = parts[1].Trim().Trim('"');

                switch (key)
                {
                    case "mainWndSx":
                        settings.mainWndSx = int.Parse(value);
                        break;
                    case "mainWndSy":
                        settings.mainWndSy = int.Parse(value);
                        break;
                    case "mainWndDx":
                        settings.mainWndDx = int.Parse(value);
                        break;
                    case "mainWndDy":
                        settings.mainWndDy = int.Parse(value);
                        break;
                    case "shortkeyWndSx":
                        settings.shortkeyWndSx = int.Parse(value);
                        break;
                    case "shortkeyWndSy":
                        settings.shortkeyWndSy = int.Parse(value);
                        break;
                    case "options":
                        settings.options = int.Parse(value);
                        break;
                    case "prefix":
                        settings.prefix =value;
                        break;
                    case "suffix":
                        settings.suffix = value;
                        break;
                    case "input":
                        settings.input = value;
                        break;
                    case "message1":
                        settings.message1 = value;
                        break;
                }
                //return settings;
            }
        }
        public void SavePropertySettings(string filePath)
        {
            StreamWriter writer = new StreamWriter(filePath,false, Encoding.UTF8);
            writer.WriteLine("[Property]");
            writer.WriteLine($"mainWndSx={settings.mainWndSx}");
            writer.WriteLine($"mainWndSy={settings.mainWndSy}");
            writer.WriteLine($"mainWndDx={settings.mainWndDx}");
            writer.WriteLine($"mainWndDy={settings.mainWndDy}");
            writer.Close();
        }
        private void button1_Click(object sender, EventArgs e)//file read
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if(ofd.ShowDialog() == DialogResult.OK )
            {
                richTextBox1.Text = File.ReadAllText(ofd.FileName);
                LoadPropertySettings(ofd.FileName);
                MessageBox.Show($"mainWndSx = {settings.mainWndSx}\nmainWndSy = {settings.mainWndSy}\nmainWndDx = {settings.mainWndDx}\nmainWndDy = {settings.mainWndDy}\n");
            }
        }

        private void button2_Click(object sender, EventArgs e)//file save
        {
            string fileName;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "경로를 지정하세요";
            saveFileDialog.OverwritePrompt = true;
            saveFileDialog.Filter = "Txt File(*.txt)|*.txt";//|Bitmap File(*.bmp)|PNG file(*png)

            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog.FileName;
                //StreamWriter filewrite = new StreamWriter(fileName);
                //filewrite.WriteLine("+입력 내용+");
                //filewrite.WriteLine(richTextBox1.Text);
                SavePropertySettings(fileName);
                MessageBox.Show("저장되었습니다");
                //filewrite.Close();
            }
        }
    }
}
